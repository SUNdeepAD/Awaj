#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  AwaJ — Setup Script
#  Installs all dependencies needed to run AwaJ on macOS.
# ─────────────────────────────────────────────────────────────────────────────

set -e
BOLD="\033[1m"
GREEN="\033[0;32m"
CYAN="\033[0;36m"
YELLOW="\033[1;33m"
RED="\033[0;31m"
RESET="\033[0m"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$SCRIPT_DIR/backend"
VENV_DIR="$BACKEND_DIR/venv"

echo ""
echo -e "${CYAN}${BOLD}  ┌──────────────────────────────────┐${RESET}"
echo -e "${CYAN}${BOLD}  │  AwaJ — Setup & Install          │${RESET}"
echo -e "${CYAN}${BOLD}  └──────────────────────────────────┘${RESET}"
echo ""

# ── 1. Check Homebrew ─────────────────────────────────────────────────────────
echo -e "${BOLD}[1/5] Checking Homebrew...${RESET}"
if ! command -v brew &>/dev/null; then
  echo -e "${YELLOW}  Homebrew not found. Installing...${RESET}"
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
else
  echo -e "${GREEN}  ✓ Homebrew found${RESET}"
fi

# ── 2. Check / install Python 3.11+ ──────────────────────────────────────────
echo ""
echo -e "${BOLD}[2/5] Checking Python...${RESET}"
PYTHON_BIN=""
for cmd in python3.12 python3.11 python3; do
  if command -v "$cmd" &>/dev/null; then
    VER=$("$cmd" --version 2>&1 | awk '{print $2}')
    MAJOR=$(echo "$VER" | cut -d. -f1)
    MINOR=$(echo "$VER" | cut -d. -f2)
    if [ "$MAJOR" -ge 3 ] && [ "$MINOR" -ge 10 ]; then
      PYTHON_BIN="$cmd"
      echo -e "${GREEN}  ✓ Found $cmd ($VER)${RESET}"
      break
    fi
  fi
done

if [ -z "$PYTHON_BIN" ]; then
  echo -e "${YELLOW}  Python 3.10+ not found. Installing via Homebrew...${RESET}"
  brew install python@3.12
  PYTHON_BIN="python3.12"
fi

# ── 3. Create virtual environment ─────────────────────────────────────────────
echo ""
echo -e "${BOLD}[3/5] Setting up Python virtual environment...${RESET}"
if [ ! -d "$VENV_DIR" ]; then
  "$PYTHON_BIN" -m venv "$VENV_DIR"
  echo -e "${GREEN}  ✓ Virtual environment created at backend/venv${RESET}"
else
  echo -e "${GREEN}  ✓ Virtual environment already exists${RESET}"
fi

VENV_PIP="$VENV_DIR/bin/pip"
VENV_PY="$VENV_DIR/bin/python3"

"$VENV_PIP" install --upgrade pip --quiet

# ── 4. Install Python packages ────────────────────────────────────────────────
echo ""
echo -e "${BOLD}[4/5] Installing Python packages...${RESET}"
echo -e "  Installing: edge-tts, pytchat, flask, flask-socketio, sounddevice, soundfile..."
"$VENV_PIP" install -r "$BACKEND_DIR/requirements.txt" --quiet
echo -e "${GREEN}  ✓ Python packages installed${RESET}"

# Check for portaudio (needed by sounddevice)
if ! brew list portaudio &>/dev/null; then
  echo -e "${YELLOW}  Installing portaudio (required for audio)...${RESET}"
  brew install portaudio
fi

# ── 5. Install Node.js / Electron ─────────────────────────────────────────────
echo ""
echo -e "${BOLD}[5/5] Installing Node.js dependencies...${RESET}"
if ! command -v node &>/dev/null; then
  echo -e "${YELLOW}  Node.js not found. Installing via Homebrew...${RESET}"
  brew install node
fi
echo -e "${GREEN}  ✓ Node.js $(node --version)${RESET}"

cd "$SCRIPT_DIR"
npm install --quiet
echo -e "${GREEN}  ✓ Electron and Node packages installed${RESET}"

# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}  ✓ Setup complete!${RESET}"
echo ""
echo -e "  To run AwaJ:"
echo -e "    ${CYAN}npm start${RESET}       — Launch the app"
echo -e "    ${CYAN}npm run build${RESET}   — Build .dmg installer"
echo ""
