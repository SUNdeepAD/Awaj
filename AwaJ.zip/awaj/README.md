# AwaJ
### YouTube Live Chat TTS — for streamers

AwaJ monitors a YouTube live stream chat for trigger words (like `!loud`) and reads matching comments aloud using Microsoft Edge TTS — with voice selection, per-user cooldowns, a live queue, audio device routing, and streamer profiles.

---

## Requirements

- **macOS** 12 Monterey or later (Intel or Apple Silicon)
- Internet connection (for YouTube chat + Edge TTS)

---

## Quick Start

```bash
# 1. Clone / download this folder, then:
bash setup.sh

# 2. Launch AwaJ
npm start
```

`setup.sh` automatically installs:
- Python 3.12 (via Homebrew if needed)
- All Python packages in a local `backend/venv`
- Node.js + Electron

---

## Building a .dmg Installer

```bash
npm run build
# Output: dist/AwaJ-1.0.0.dmg
```

---

## How It Works

```
Electron (UI)  ←──WebSocket──→  Python Flask (backend)
                                     │
                               pytchat (YouTube chat)
                               edge-tts (TTS synthesis)
                               sounddevice (audio output)
```

The Python backend runs silently on `localhost:5001`. The Electron UI communicates with it over HTTP + WebSocket.

---

## Features

| Feature | Details |
|---|---|
| YouTube Chat | Connects via pytchat using Video ID |
| Trigger Words | Customizable list, case-insensitive matching |
| TTS Engine | Microsoft Edge TTS (edge-tts) — no API key needed |
| Voices | EN Male/Female, JP Male/Female, NE Male/Female |
| Queue | Messages queued and spoken one-by-one |
| Cooldown | Per-user rate limiting (configurable) |
| Audio Device | Route TTS to any output device (great for OBS) |
| Profiles | Save/load named configurations |
| Persistence | All settings auto-saved to `backend/settings.json` |

---

## Usage

1. Paste a YouTube **Video ID** or full URL into the connect bar
2. Click **Connect**
3. When a viewer types a trigger word (e.g. `!loud`), their message is spoken aloud
4. Use the **Voice** tab to set voice, volume, and output device
5. Use the **Triggers** tab to add/remove trigger words
6. Use the **Rules** tab for cooldown and streamer-ignore settings
7. Use the **Profiles** tab to save and switch configurations

---

## OBS Integration

To route TTS audio separately in OBS:
1. Create a **Virtual Audio Cable** (e.g. BlackHole, VB-Cable)
2. In AwaJ → Voice tab → Output Device → select the virtual cable
3. In OBS → Add an **Audio Input Capture** source → select the same virtual cable

---

## Voices Available

| ID | Language | Gender |
|---|---|---|
| `en-US-GuyNeural` | English | Male |
| `en-US-JennyNeural` | English | Female |
| `ja-JP-KeitaNeural` | Japanese | Male |
| `ja-JP-NanamiNeural` | Japanese | Female |
| `ne-NP-SagarNeural` | Nepali | Male |
| `ne-NP-HemkalaNeural` | Nepali | Female |

---

## Troubleshooting

**Backend won't start**
- Run `bash setup.sh` again
- Check that Python 3.10+ is in your PATH

**No audio**
- Click **Refresh Devices** in the Voice tab
- Ensure your output device is selected (or leave as "System Default")
- Hit the **Test** button to verify audio

**Chat not connecting**
- Confirm the stream is currently live
- Check that the Video ID is correct (e.g. `Io_5JyeCK4c` from `youtube.com/watch?v=Io_5JyeCK4c`)
- Some streams have chat disabled — AwaJ cannot connect to those

---

## License

MIT
