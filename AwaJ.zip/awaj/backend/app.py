#!/usr/bin/env python3
"""
AwaJ Backend — YouTube Chat TTS Engine
Flask + SocketIO server that bridges YouTube live chat with edge-tts
"""

import asyncio
import io
import json
import logging
import os
import queue
import re
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path

import edge_tts
import pytchat
import sounddevice as sd
import soundfile as sf
from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_socketio import SocketIO, emit

# ─── Setup ─────────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("awaj")

app = Flask(__name__)
app.config["SECRET_KEY"] = "awaj-secret-2025"
CORS(app, resources={r"/*": {"origins": "*"}})
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

SETTINGS_FILE = Path(__file__).parent / "settings.json"

# ─── Default Settings ──────────────────────────────────────────────────────────
DEFAULT_SETTINGS = {
    "trigger": "!loud",
    "voice": "en-US-JennyNeural",
    "volume": 0.8,
    "cooldown": 10,
    "ignore_streamer": True,
    "ding_enabled": True,
    "output_device": None,
    "profiles": {
        "Default": {
            "triggers": ["!loud", "!tts"],
            "voice": "en-US-JennyNeural",
            "volume": 0.8,
            "cooldown": 10,
        }
    },
    "active_profile": "Default",
    "video_id": "",
    "streamer_channel": "",
}

AVAILABLE_VOICES = [
    {"id": "en-US-GuyNeural",      "label": "English — Male (Guy)"},
    {"id": "en-US-JennyNeural",    "label": "English — Female (Jenny)"},
    {"id": "ja-JP-KeitaNeural",    "label": "Japanese — Male (Keita)"},
    {"id": "ja-JP-NanamiNeural",   "label": "Japanese — Female (Nanami)"},
    {"id": "ne-NP-SagarNeural",    "label": "Nepali — Male (Sagar)"},
    {"id": "ne-NP-HemkalaNeural",  "label": "Nepali — Female (Hemkala)"},
]

# ─── State ─────────────────────────────────────────────────────────────────────
state = {
    "settings": {},
    "connected": False,
    "video_id": None,
    "chat_thread": None,
    "tts_thread": None,
    "tts_queue": queue.Queue(),
    "tts_queue_list": [],       # visible snapshot for UI
    "user_last_trigger": {},    # cooldown tracking
    "chat": None,               # pytchat instance
    "speaking": False,
    "messages": [],
}

# ─── Settings I/O ──────────────────────────────────────────────────────────────
def load_settings():
    if SETTINGS_FILE.exists():
        try:
            with open(SETTINGS_FILE) as f:
                data = json.load(f)
            merged = {**DEFAULT_SETTINGS, **data}
            log.info("Settings loaded.")
            return merged
        except Exception as e:
            log.warning(f"Failed to load settings: {e}")
    return dict(DEFAULT_SETTINGS)

def save_settings(settings):
    try:
        with open(SETTINGS_FILE, "w") as f:
            json.dump(settings, f, indent=2)
    except Exception as e:
        log.error(f"Failed to save settings: {e}")

state["settings"] = load_settings()

# ─── Audio Devices ─────────────────────────────────────────────────────────────
def get_audio_devices():
    devices = sd.query_devices()
    output_devs = []
    for i, d in enumerate(devices):
        if d["max_output_channels"] > 0:
            output_devs.append({"id": i, "name": d["name"]})
    return output_devs

def play_audio_bytes(audio_bytes: bytes, volume: float = 1.0, device_id=None):
    """Play raw audio bytes through the selected output device."""
    try:
        buf = io.BytesIO(audio_bytes)
        data, samplerate = sf.read(buf, dtype="float32")
        data = data * max(0.0, min(1.0, volume))
        kwargs = {"samplerate": samplerate, "blocking": True}
        if device_id is not None:
            kwargs["device"] = device_id
        sd.play(data, **kwargs)
    except Exception as e:
        log.error(f"Audio playback error: {e}")

# ─── TTS Engine ────────────────────────────────────────────────────────────────
async def generate_tts_bytes(text: str, voice: str) -> bytes:
    communicate = edge_tts.Communicate(text, voice)
    audio_chunks = []
    async for chunk in communicate.stream():
        if chunk["type"] == "audio":
            audio_chunks.append(chunk["data"])
    return b"".join(audio_chunks)

def tts_worker():
    """Background thread that drains the TTS queue sequentially."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    log.info("TTS worker started.")
    while True:
        try:
            item = state["tts_queue"].get(timeout=1)
        except queue.Empty:
            continue

        if item is None:
            break  # poison pill

        msg_id, text, author = item["id"], item["text"], item["author"]

        # Remove from visible queue snapshot
        state["tts_queue_list"] = [i for i in state["tts_queue_list"] if i["id"] != msg_id]
        socketio.emit("queue_update", {"queue": state["tts_queue_list"]})

        settings = state["settings"]
        voice  = settings.get("voice", "en-US-JennyNeural")
        volume = float(settings.get("volume", 0.8))
        device = settings.get("output_device", None)

        # Notify UI: speaking started
        state["speaking"] = True
        socketio.emit("tts_start", {"id": msg_id, "author": author, "text": text})

        try:
            audio_bytes = loop.run_until_complete(generate_tts_bytes(text, voice))
            play_audio_bytes(audio_bytes, volume, device)
        except Exception as e:
            log.error(f"TTS error: {e}")

        # Notify UI: speaking done
        state["speaking"] = False
        socketio.emit("tts_end", {"id": msg_id})
        state["tts_queue"].task_done()

# ─── YouTube Chat Poller ────────────────────────────────────────────────────────
def chat_worker(video_id: str):
    log.info(f"Connecting to YouTube chat for video: {video_id}")
    try:
        chat = pytchat.create(video_id=video_id, interruptable=False)
        state["chat"] = chat
        state["connected"] = True
        socketio.emit("connection_status", {"connected": True, "video_id": video_id})
        log.info("Chat connected.")
    except Exception as e:
        log.error(f"Failed to connect to chat: {e}")
        socketio.emit("connection_status", {"connected": False, "error": str(e)})
        return

    settings = state["settings"]

    while chat.is_alive() and state.get("running", True):
        try:
            for c in chat.get().sync_items():
                process_message(c, settings)
        except Exception as e:
            log.warning(f"Chat fetch error: {e}")
        time.sleep(0.5)

    state["connected"] = False
    socketio.emit("connection_status", {"connected": False})
    log.info("Chat disconnected.")

def process_message(c, settings):
    """Process a single chat message."""
    msg_id   = c.id
    author   = c.author.name
    text     = c.message
    ts       = datetime.now().strftime("%H:%M:%S")

    msg_data = {
        "id":       msg_id,
        "author":   author,
        "text":     text,
        "time":     ts,
        "triggered": False,
        "type":     c.type,
    }

    # Trigger detection — single trigger word, supports ! prefix, case-insensitive
    trigger = settings.get("trigger", "!loud").strip()
    pattern = re.compile(re.escape(trigger), re.IGNORECASE)
    matched = bool(pattern.search(text))

    if matched:
        # Cooldown check
        cooldown = int(settings.get("cooldown", 10))
        now      = time.time()
        last     = state["user_last_trigger"].get(author, 0)

        if now - last < cooldown:
            log.info(f"Cooldown: ignoring {author} ({int(cooldown - (now - last))}s left)")
        else:
            state["user_last_trigger"][author] = now
            msg_data["triggered"] = True

            # Strip the trigger word, then prepend username for context
            spoken_text = pattern.sub("", text).strip()
            if not spoken_text:
                spoken_text = text  # fallback: message was only the trigger word
            spoken_text = f"{author} said {spoken_text}" 

            queue_item = {"id": msg_id, "author": author, "text": spoken_text, "display_text": text, "time": ts}
            state["tts_queue"].put(queue_item)
            state["tts_queue_list"].append(queue_item)
            socketio.emit("queue_update", {"queue": state["tts_queue_list"]})
            socketio.emit("ding", {})

    # Always send message to UI
    state["messages"].append(msg_data)
    if len(state["messages"]) > 500:
        state["messages"] = state["messages"][-500:]
    socketio.emit("chat_message", msg_data)

# ─── REST API ──────────────────────────────────────────────────────────────────
@app.route("/api/status")
def api_status():
    return jsonify({
        "connected": state["connected"],
        "video_id":  state["video_id"],
        "speaking":  state["speaking"],
        "queue_len": state["tts_queue"].qsize(),
    })

@app.route("/api/connect", methods=["POST"])
def api_connect():
    data     = request.json or {}
    video_id = data.get("video_id", "").strip()
    if not video_id:
        return jsonify({"ok": False, "error": "video_id required"}), 400

    # Stop existing connection
    if state["connected"]:
        state["running"] = False
        if state["chat"]:
            state["chat"].terminate()
        time.sleep(1)

    state["video_id"] = video_id
    state["running"]  = True

    # Start chat thread
    t = threading.Thread(target=chat_worker, args=(video_id,), daemon=True)
    t.start()
    state["chat_thread"] = t

    return jsonify({"ok": True})

@app.route("/api/disconnect", methods=["POST"])
def api_disconnect():
    state["running"] = False
    if state["chat"]:
        try:
            state["chat"].terminate()
        except Exception:
            pass
    state["connected"] = False
    socketio.emit("connection_status", {"connected": False})
    return jsonify({"ok": True})

@app.route("/api/settings", methods=["GET"])
def api_get_settings():
    return jsonify(state["settings"])

@app.route("/api/settings", methods=["POST"])
def api_save_settings():
    data = request.json or {}
    state["settings"].update(data)
    save_settings(state["settings"])
    return jsonify({"ok": True})

@app.route("/api/voices")
def api_voices():
    return jsonify(AVAILABLE_VOICES)

@app.route("/api/devices")
def api_devices():
    return jsonify(get_audio_devices())

@app.route("/api/test_tts", methods=["POST"])
def api_test_tts():
    data = request.json or {}
    text  = data.get("text", "The quick brown fox jumps over the lazy dog.")
    voice = data.get("voice", state["settings"].get("voice", "en-US-JennyNeural"))
    vol   = float(data.get("volume", state["settings"].get("volume", 0.8)))
    dev   = data.get("device", state["settings"].get("output_device", None))

    def run_test():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            audio = loop.run_until_complete(generate_tts_bytes(text, voice))
            play_audio_bytes(audio, vol, dev)
        except Exception as e:
            log.error(f"Test TTS error: {e}")

    threading.Thread(target=run_test, daemon=True).start()
    return jsonify({"ok": True})

@app.route("/api/queue/clear", methods=["POST"])
def api_clear_queue():
    while not state["tts_queue"].empty():
        try:
            state["tts_queue"].get_nowait()
            state["tts_queue"].task_done()
        except queue.Empty:
            break
    state["tts_queue_list"] = []
    socketio.emit("queue_update", {"queue": []})
    return jsonify({"ok": True})

@app.route("/api/messages")
def api_messages():
    return jsonify(state["messages"][-200:])

@app.route("/api/profiles", methods=["GET"])
def api_get_profiles():
    return jsonify({
        "profiles":       list(state["settings"].get("profiles", {}).keys()),
        "active_profile": state["settings"].get("active_profile", "Default"),
    })

@app.route("/api/profiles/save", methods=["POST"])
def api_save_profile():
    data = request.json or {}
    name = data.get("name", "").strip()
    if not name:
        return jsonify({"ok": False, "error": "name required"}), 400
    s = state["settings"]
    if "profiles" not in s:
        s["profiles"] = {}
    s["profiles"][name] = {
        "triggers": s.get("triggers", []),
        "voice":    s.get("voice", "en-US-JennyNeural"),
        "volume":   s.get("volume", 0.8),
        "cooldown": s.get("cooldown", 10),
    }
    save_settings(s)
    return jsonify({"ok": True})

@app.route("/api/profiles/load", methods=["POST"])
def api_load_profile():
    data = request.json or {}
    name = data.get("name", "").strip()
    s    = state["settings"]
    prof = s.get("profiles", {}).get(name)
    if not prof:
        return jsonify({"ok": False, "error": "profile not found"}), 404
    s.update(prof)
    s["active_profile"] = name
    save_settings(s)
    return jsonify({"ok": True, "settings": s})

# ─── SocketIO Events ───────────────────────────────────────────────────────────
@socketio.on("connect")
def on_connect():
    log.info("Client connected via WebSocket.")
    emit("connection_status", {"connected": state["connected"]})
    emit("settings",          state["settings"])
    emit("queue_update",      {"queue": state["tts_queue_list"]})

# ─── Boot ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Start TTS worker
    tts_t = threading.Thread(target=tts_worker, daemon=True)
    tts_t.start()
    state["tts_thread"] = tts_t

    log.info("AwaJ backend starting on port 5001…")
    socketio.run(app, host="127.0.0.1", port=5001, debug=False, use_reloader=False, allow_unsafe_werkzeug=True)
