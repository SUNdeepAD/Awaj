/**
 * AwaJ — Electron Main Process
 * Launches the Python backend and opens the renderer window.
 */

const { app, BrowserWindow, ipcMain, shell } = require("electron");
const path   = require("path");
const { spawn, execSync } = require("child_process");
const fs     = require("fs");

let mainWindow  = null;
let pythonProc  = null;
const BACKEND_PORT = 5001;
const BACKEND_URL  = `http://127.0.0.1:${BACKEND_PORT}`;

// ─── Python Backend ─────────────────────────────────────────────────────────
function startPythonBackend() {
  // When packaged, backend is unpacked from asar into app.asar.unpacked/
  // When in dev, it sits next to main.js as normal.
  const isPackaged = app.isPackaged;
  const backendBase = isPackaged
    ? path.join(process.resourcesPath, "app.asar.unpacked", "backend")
    : path.join(__dirname, "backend");

  const backendPath = path.join(backendBase, "app.py");

  // Try bundled venv first, fall back to system python3
  const venvPython = path.join(backendBase, "venv", "bin", "python3");
  const pythonBin  = fs.existsSync(venvPython) ? venvPython : "python3";

  console.log(`[main] Starting backend with: ${pythonBin} ${backendPath}`);
  console.log(`[main] isPackaged: ${isPackaged}, backendBase: ${backendBase}`);

  pythonProc = spawn(pythonBin, [backendPath], {
    cwd: backendBase,
    env: { ...process.env },
  });

  pythonProc.stdout.on("data", (d) => process.stdout.write(`[py] ${d}`));
  pythonProc.stderr.on("data", (d) => process.stderr.write(`[py-err] ${d}`));

  pythonProc.on("exit", (code) => {
    console.log(`[main] Python backend exited with code ${code}`);
    pythonProc = null;
  });
}

function waitForBackend(retries = 20) {
  return new Promise((resolve, reject) => {
    const http = require("http");
    let attempts = 0;
    const check = () => {
      http.get(`${BACKEND_URL}/api/status`, (res) => {
        if (res.statusCode === 200) resolve();
        else retry();
      }).on("error", retry);
    };
    const retry = () => {
      if (++attempts >= retries) return reject(new Error("Backend did not start"));
      setTimeout(check, 500);
    };
    check();
  });
}

// ─── Window ──────────────────────────────────────────────────────────────────
async function createWindow() {
  mainWindow = new BrowserWindow({
    width:  1300,
    height: 820,
    minWidth:  960,
    minHeight: 600,
    titleBarStyle: "hiddenInset",
    backgroundColor: "#0D0D14",
    webPreferences: {
      preload:         path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration:  false,
    },
    icon: path.join(__dirname, "assets", "icon.png"),
    show: false,
  });

  mainWindow.once("ready-to-show", () => mainWindow.show());

  mainWindow.loadFile(path.join(__dirname, "index.html"), {
    query: { backendUrl: BACKEND_URL },
  });

  // Open external links in browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });
}

// ─── IPC Handlers ────────────────────────────────────────────────────────────
ipcMain.handle("get-backend-url", () => BACKEND_URL);

// ─── App Lifecycle ────────────────────────────────────────────────────────────
app.whenReady().then(async () => {
  startPythonBackend();
  try {
    await waitForBackend();
    console.log("[main] Backend ready.");
  } catch (e) {
    console.error("[main] Backend failed to start:", e.message);
  }
  createWindow();
});

app.on("window-all-closed", () => {
  if (pythonProc) {
    pythonProc.kill("SIGTERM");
  }
  if (process.platform !== "darwin") app.quit();
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

app.on("before-quit", () => {
  if (pythonProc) {
    pythonProc.kill("SIGTERM");
  }
});
