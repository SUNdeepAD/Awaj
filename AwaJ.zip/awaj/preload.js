/**
 * AwaJ — Preload Script
 * Safely exposes Electron APIs to the renderer via contextBridge.
 */

const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("awaj", {
  getBackendUrl: () => ipcRenderer.invoke("get-backend-url"),
});
